import fs from 'node:fs/promises';
import {safeUrl} from '../public/core.mjs';
const root=new URL('../',import.meta.url);const json=JSON.parse(await fs.readFile(new URL('public/public-campaigns.json',root),'utf8'));
if(!json.campaigns.length)throw new Error('Empty catalog');
for(const c of json.campaigns){if(!safeUrl(c.url,json.allowedDomains)||c.applyUrl&&!safeUrl(c.applyUrl,json.allowedDomains))throw new Error('Unsafe campaign URL');for(const k of Object.keys(c))if(/cookie|token|email|address|phone|state|password|session/i.test(k))throw new Error('Private field: '+k);}
for(const p of ['index.html','styles.css','app.mjs','core.mjs','manifest.webmanifest','service-worker.js','icons/icon-192.png','icons/icon-512.png','public-campaigns.json'])await fs.access(new URL('public/'+p,root));
const m=JSON.parse(await fs.readFile(new URL('public/manifest.webmanifest',root),'utf8'));if(m.scope!=='./'||m.start_url!=='./')throw new Error('Pages subpath');
console.log('Build verified: static PWA, '+json.campaigns.length+' campaigns, public/ only');
